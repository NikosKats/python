num = 0
count1 = 0
count2 = 0

file = open("file1.txt", "r") 

str = file.read() 
print str

for x in range(0,len(str)):
  if str[x].isdigit():
    num+=1

for x in range(0,len(str)):
  if str[x] == "a" or str[x] == "e" or str[x] == "i" or str[x] == "o" or str[x] == "u":
    count1+=1

for x in range(0,len(str)):
  if str[x] == "b" or str[x] == "c" or str[x] == "d" or str[x] == "f" or str[x] == "g" or str[x] == "h" or str[x] == "j" or str[x] == "k" or str[x] == "l" or str[x] == "m" or str[x] == "n" or str[x] == "p" or str[x] == "q" or str[x] == "r" or str[x] == "s" or str[x] == "t" or str[x] == "v" or str[x] == "w" or str[x] == "x" or str[x] == "y" or str[x] == "z":
    count2+=1
   
print ("ari8moi: %d"%num)   
print ("fwnhenta: %d"%count1) 
print ("sumfwna: %d"%count2) 